#include "CsSerialChannel.h"

QElapsedTimer stimer;

CsSerialChannel::CsSerialChannel()
  {

  }
