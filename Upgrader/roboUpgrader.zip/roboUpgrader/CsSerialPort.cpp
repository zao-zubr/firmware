#include "CsSerialPort.h"

#include <QSettings>
#include <QDebug>




CsSerialPort::CsSerialPort(const QString portName, int baudrate)
  {
  //Open port
  mPort.setPortName( portName );
  if( mPort.open(QIODevice::ReadWrite) ) {
    mPort.setBaudRate( baudrate );
    mPort.setDataBits( QSerialPort::Data8 );
    mPort.setStopBits( QSerialPort::OneStop );
    mPort.setFlowControl( QSerialPort::NoFlowControl );
    mPort.setParity( QSerialPort::NoParity );
//      qDebug() << "serial init";
    }
  }




//!
//! \brief rxClear Очистить очередь приема
//!
void CsSerialPort::rxClear()
  {
  if( mPort.isOpen() ) {
    mPort.readAll();
    }
  }




//!
//! \brief isValid Возвращает валидность порта, т.е. что он успешно открыт и проинициализирован
//! \return        Валидность порта, т.е. что он успешно открыт и проинициализирован
//!
bool CsSerialPort::isValid() const
  {
  return mPort.isOpen();
  }






//!
//! \brief msgWrite Выполняет запись в порт сообщения msg
//! \param msg      Сообщение, которое нужно записать в порт, т.е. отправить
//! \return         true когда запись в порт выполнена успешно
//!
//! Данная функция вызывает функцию ОС write. Умозрительно, данные отправляются в буфер, далее
//! в соответствии с циклом usb блок данных отправляется через usb на преобразователь usb-uart
//! и, наконец, передается по uart с заданной скоростью.
//!
//! При этом, функция write и, соответственно, эта функция не ожидают фактической передачи блока
//! через uart, а возвращаются сразу после записи в буфер ОС. Таким образом минимизируется время
//! занятия процессора на передачу байтов
bool CsSerialPort::msgWrite(CsMessageOut &msg)
  {
  if( !mPort.isOpen() )
    return false;

  int ret = mPort.write( msg.buffer(), msg.length() );
  //qDebug() << "read to write" << stimer.elapsed();
  stimer.restart();
  return ret == msg.length();
  }




//!
//! \brief msgRead Выполняет чтение сообщений из порта в msg
//! \param msg     Сообщение, в которое будет произведено чтение
//! \return        true - если данные прочитаны из порта и false - если нету данных
//!
//! Данные, которые поступают по uart передаются блоками через usb и аккумулируются в буфере
//! ОС. Данная функция извлекает все доступные на момент вызова данные и размещает их в буфере сообщения.
//! Таким образом, в буфере сообщения могут быть последовательно расположены несколько сообщений.
//!
//! Также нету гарантий, что передача через usb не поделит данные на несколько блоков, т.е. может быть,
//! что считанные данные неполные и далее поступит недостающий фрагмент. Чтобы избежать этого эффекта
//! мы используют цикл ожидания между посылкой запроса и считыванием данных. Таким образом, все
//! данные, которые отправлены по uart должны будут собраться в буфере ОС, откуда они будут считаны
//! этой функцией.
bool CsSerialPort::msgRead(CsMessageBuf256 &msg)
  {
  if( !mPort.isOpen() )
    return false;
  //Прочитать полученное сообщение
  //Прочитать полученное сообщение
  msg.mLength = mPort.read( msg.mBuffer, msg.mSize );
  return msg.mLength != 0;
  }
