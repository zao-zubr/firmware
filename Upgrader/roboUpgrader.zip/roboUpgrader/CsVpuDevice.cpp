/*
Project "Загрузчик прошивок в кабельный тестер"
Copyright (c) 2026 Alexander Sibilev

Author
  Alexander Sibilev S.

Web
  www.SalixEDA.org

Description
  Всю "грязную" работу делает CsVpuDevice. Он выпилен из IronArt, поэтому может иметь
  не относящиеся к делу артефакты.

  Единственный экземпляр этого класса получает имя файла с конфигурацией. Считывает
  ее, формирует прошивку. Прошивка включает заголовок, который состоит из записей
  наименование_прошивки:адрес_начала_прошивки_во_flash:длина
  Здесь flash имеется ввиду микросхема внешней флэш-памяти в калибраторе.

  На сегодня калибратор поддерживает одновременно не более восьми прошивок.

  После заголовка идут сами прошивки.

  Загрузка этого добра в калибратор стартует вызовом start(). Там
  реализована машина состояний, которая сначала подключается к калибратору,
  затем стирает внешнюю память калибратора, затем передает
  подготовленную прошивку.
*/
#include "CsVpuDevice.h"
#include "../roboTester/Src/roboTesterBook.h"
#include "SvLib/SvJsonIO.h"

#include <QTimer>
#include <QFile>
#include <QSerialPortInfo>
#include <QCoreApplication>
#include <QDebug>

CsVpuDevice::CsVpuDevice(QObject *parent)
  : QObject{parent}
  , mConnectCount(0)
  , mPortIndex(0)      //! Счетчик перебора доступных портов для подключения к контроллеру
  , mFlashAddress(0)
  , mFlashCount(0)
  {
  memset( mFlashData, 0xff, sizeof(mFlashData) );
  }




bool CsVpuDevice::loadHex(const QString &configFile)
  {
  QFile file(configFile);
  if( file.open(QIODevice::ReadOnly) ) {
    QJsonObject obj( svJsonObjectFromByteArray(file.readAll()) );
    SvJsonReader js( obj );
    QStringList list;
    js.jsonListString( "hex files", list );

    UpgradeHeader upgradeHeader;
    memset( &upgradeHeader, 0, sizeof(upgradeHeader) );

    mFlashCount = 1024;
    int index = 0;
    for( int i = 0; i + 1 < list.count(); i += 2 ) {
      //Четной строкой идет имя файла
      QString fileName( list.at(i) );
      QString title( list.at(i+1) );
      upgradeHeader.mSlot[index].mOffset = mFlashCount;
      if( parseUpgrade( fileName, upgradeHeader.mSlot[index].mSize ) ) {
        upgradeHeader.mSlot[index].setTitle( (const char16_t *)(title.utf16()) );
        index++;
        }
      }

    //Теперь записать заголовок
    memcpy( mFlashData, &upgradeHeader, sizeof(upgradeHeader) );
    mFlashAddress = 0;
    return true;
    }
  return false;
  }




void CsVpuDevice::start()
  {
  //Периодическая функция обмена с роботом
  QTimer *timer = new QTimer();
  connect( timer, &QTimer::timeout, this, &CsVpuDevice::periodic );
  timer->start( 200 );

  //Периодическая функция для повтора обмена при ошибках сообщений
  timer = new QTimer();
  connect( timer, &QTimer::timeout, this, &CsVpuDevice::msgPeriodic );
  timer->start( 10 );
  }



//Преобразование четырех байтов в беззнаковое целое
quint32 unpack32( char ch0, char ch1, char ch2, char ch3 ) {
  return  (static_cast<quint32>(ch0) & 0xff) |
         ((static_cast<quint32>(ch1) & 0xff) << 8) |
         ((static_cast<quint32>(ch2) & 0xff) << 16) |
         ((static_cast<quint32>(ch3) & 0xff) << 24);
  }






//!
//! \brief periodic Периодическая функция для связи с контроллером
//!
void CsVpuDevice::periodic()
  {
  if( mSerialChannel.isNull() ) {
    //Порт не открыт, пробуем открыть
    QString factPort;
    auto serialPortList = QSerialPortInfo::availablePorts();
    if( mPortIndex >= serialPortList.count() )
      mPortIndex = 0;
    if( mPortIndex < serialPortList.count() )
      factPort = serialPortList.at(mPortIndex++).portName();
    else return;

    mSerialChannel.reset( new CsSerialPort( factPort, 3000000 ) );
    if( mSerialChannel->isValid() ) {
      //Очистить очередь приема
      mSerialChannel->rxClear();
      //Подключить порт к приемнику данных
      connect( mSerialChannel->ioDevice(), &QIODevice::readyRead, this, &CsVpuDevice::bytesRead );
      qDebug() << "opened" << factPort;
      //Запросить информацию
      queryInfo();
      mConnectCount = 30;
      }
    else portClose();
    }
  }


static int msgSendCount = 1;
//!
//! \brief msgPeriodic Периодическая функция для повтора передачи при ошибке обмена
//!
void CsVpuDevice::msgPeriodic()
  {
  if( !mSerialChannel.isNull() ) {
    //Порт открыт и идет обмен
    static QByteArray line;
    if( mReceived ) {
      mReceived--;
      if( mReceived == 2 ) {
        //Выгрести весь буфер
        line = mSerialChannel->ioDevice()->readAll();
        static int errorCount;
        errorCount++;
        qDebug() << "Repeate send" << line << "errors, \%" << double(errorCount) / double(msgSendCount) * 100.0;
        //Повторить отправку
        mSerialChannel->msgWrite( mOut );
        }
      if( mReceived <= 0 ) {
        line = mSerialChannel->ioDevice()->readAll();
        qDebug() << "Not received" << line;
        //Если время ожидания истекло, то закрываем порт
        portClose();
        }
      }
    }

  }



//!
//! \brief bytesRead Слот вызывается при наличии байтов для чтения
//!
void CsVpuDevice::bytesRead()
  {
  //qDebug() << "bytes read" << stimer.elapsed() << mSerialChannel->ioDevice()->bytesAvailable();
  if( mSerialChannel.isNull() )
    return;
  while( !mSerialChannel.isNull() && mSerialChannel->ioDevice()->canReadLine() ) {
    //qDebug() << "write to read" << stimer.elapsed();
    stimer.restart();
    CsMessageBuf256 msgBuf;
    CsMessageIn msgIn( msgBuf, 1 );
    if( !mSerialChannel->msgRead( msgBuf ) || !msgIn.checkCrc( msgBuf.mLength - 1 ) )
      continue;

    //qDebug() << "Answer" << msgIn.hostCmd();
    switch( msgIn.hostCmd() ) {
      case RB_CB_INFO :
        mConnectCount--;
        if( mConnectCount <= 0 ) {
          //Реагируем на информацию только когда истечет время

          //Получена информация от контроллера
          // i8[32] - тип оборудования
          // i16    - версия ПО
          char name[35];
          for( int i = 0; i < 32; i++ ) {
            name[i] = msgIn.getInt8();
            }
          name[32] = 0;

          int version = msgIn.getInt16();


          mController = QString::fromUtf8( name );
          if( mController.startsWith( QString(RB_NAME) ) ) {
            //Выдать
            qDebug() << tr("Подключен %1 V%2").arg(mController).arg(version);
            qDebug() << "Begin flash";
            qDebug() << "Erase all memory";
            mFlashAddress = 0;
            flashData();
            }
          else {
            qDebug() << "Connected not tester" << mController;
            mController.clear();
            }
          }
        else
          queryInfo();
        break;

      // case RB_CB_PARAM_VALUE : {
      //   //Вернулось значение параметра
      //   // i16 - индекс параметра
      //   // i32 - значение параметра
      //   int ctrlIndex = msgIn.getInt16();
      //   int ctrlValue = msgIn.getInt32();
      //   }
      //   break;



      case RB_CB_FLASH_OK :
        //Данные записаны успешно, можно передавать следующий блок
        if( (mFlashAddress & 0xff) == 0 ) {
          qDebug() << "Written sector" << (mFlashAddress >> 8);
          }
        if( mFlashAddress < ((mFlashCount + 255) & ~0xff) )
          flashData();
        else {
          //Завершаем программу
          QCoreApplication::quit();
          }
        break;
      }
    }
  }



//!
//! \brief portClose Закрыть последовательный порт
//!
void CsVpuDevice::portClose()
  {
  //Закрыть порт
  if( mSerialChannel->isValid() ) {
    disconnect( mSerialChannel->ioDevice(), &QIODevice::readyRead, this, &CsVpuDevice::bytesRead );
    mSerialChannel->ioDevice()->close();
    }
  mSerialChannel.reset(nullptr);
  if( !mController.isEmpty() ) {
    //Сообщить, что порт закрыт и подключения нету
    mController.clear();
    qDebug() << tr("Не подключен");
    }
  }




//!
//! \brief queryInfo Запросить информацию по контроллеру
//!
void CsVpuDevice::queryInfo()
  {
  if( !mSerialChannel.isNull() ) {
//    CsMessageOut msgOut;
//    msgOut.hostBeginQuery( RB_CB_INFO_GET );
//    msgOut.hostEnd();
//    mSerialChannel->msgWrite( msgOut );
    mOut.hostBeginQuery( RB_CB_INFO_GET );
    mOut.hostEnd();
    mSerialChannel->msgWrite( mOut );
    mReceived = 20;
    }
  }



//!
//! \brief flashData Создать сообщение с прошивкой флэш и отправить
//!
void CsVpuDevice::flashData()
  {
  if( mSerialChannel.isNull() )
    return;
  //i32    - адрес блока
  //i8[32] - блок данных
  mOut.hostBeginQuery( RB_CB_FLASH_DATA );
  mOut.addInt32( mFlashAddress );
  for( int i = 0; i < 32; i++ )
    mOut.addInt8( mFlashData[mFlashAddress++] );
  mOut.hostEnd();
  mSerialChannel->msgWrite( mOut );
  if( mFlashAddress == 32 )
    //Это был первый блок, при этом стирается вся память
    mReceived = 2000;
  else if( (mFlashAddress & 0xff) == 0 )
    mReceived = 40;
  else
    mReceived = 4;
  }





//!
//! \brief parseUpgrade     Парсить hex файл и готовить его для передачи в контроллер
//! \param upgradeFile      Имя файла
//! \param upgradeByteCount Количество байт, размещенных в буфере прошивки
//! \return                 true - когда файл распарсен успешно
//!
bool CsVpuDevice::parseUpgrade(const QString &upgradeFile, int &upgradeByteCount )
  {
  int startCount( mFlashCount );
  //Пробуем открыть файл
  QFile file(upgradeFile);
  if( file.open( QIODevice::ReadOnly ) ) {
    //Парсим hex-файл
    QTextStream is( file.readAll() );
    QString line;
    quint32 upperAddress(0);

    //Собственно парсер
    while( is.readLineInto( &line ) ) {
      if( !line.isEmpty() && line.startsWith( QChar(':') )  ) {
        //Строка принадлежит к intel-hex
        //Получить все байты
        QByteArray parsedLine = QByteArray::fromHex( line.mid(1).toLatin1() );
        int byteCount = parsedLine.at(0) & 0xff;
        quint32 address( unpack32( parsedLine.at(2), parsedLine.at(1), 0, 0 ) );
        char lineType = parsedLine.at(3);
        if( lineType == 0 ) {
          //Данные
          //Подготавливаем полный адрес
          address |= upperAddress;
          int i;
          for( i = 0; i + 3 < byteCount; i += 4 ) {
            //Записать адрес
            appendFlashData( address );
            address += 4;
            //Записать данные
            appendFlashData( unpack32( parsedLine.at(4+i), parsedLine.at(5+i), parsedLine.at(6+i), parsedLine.at(7+i) )  );
            }
          //В заключении идут не целые данные
          if( i < byteCount ) {
            //Записать адрес
            appendFlashData( address );
            //Записать данные
            appendFlashData( unpack32( parsedLine.at(4+i),
                                         i+1 < byteCount ? parsedLine.at(5+i) : static_cast<char>(0xff),
                                         i+2 < byteCount ? parsedLine.at(6+i) : static_cast<char>(0xff),
                                         static_cast<char>(0xff) )  );
            }
          }
        else if( lineType == 1 ) {
          //Файл завершен
          upgradeByteCount = mFlashCount - startCount;
          return true;
          }
        else if( lineType == 4 ) {
          //Изменился старший адрес
          upperAddress = unpack32( 0, 0, parsedLine.at(5), parsedLine.at(4) );
          }
        }
      }
    }
  else {
    qDebug() << "Can't find hex file " << upgradeFile;
    }
  mFlashCount = startCount;
  upgradeByteCount = 0;
  return false;
  }




void CsVpuDevice::appendFlashData(quint32 v)
  {
  appendFlashByte( v & 0xff );
  appendFlashByte( (v >> 8) & 0xff );
  appendFlashByte( (v >> 16) & 0xff );
  appendFlashByte( (v >> 24) & 0xff );
  }

void CsVpuDevice::appendFlashByte(quint8 v)
  {
  mFlashData[mFlashCount++] = v;
  }



