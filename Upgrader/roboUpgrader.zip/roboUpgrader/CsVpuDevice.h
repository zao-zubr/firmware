/*
Project "Загрузчик прошивок в кабельный тестер"
Copyright (c) 2026 Alexander Sibilev

Author
  Alexander Sibilev S.

Web
  www.SalixEDA.org

Description
  Всю "грязную" работу делает CsVpuDevice. Он выпилен из IronArt, поэтому может иметь
  не относящиеся к делу артефакты.

  Единственный экземпляр этого класса получает имя файла с конфигурацией. Считывает
  ее, формирует прошивку. Прошивка включает заголовок, который состоит из записей
  наименование_прошивки:адрес_начала_прошивки_во_flash:длина
  Здесь flash имеется ввиду микросхема внешней флэш-памяти в калибраторе.

  На сегодня калибратор поддерживает одновременно не более восьми прошивок.

  После заголовка идут сами прошивки.

  Загрузка этого добра в калибратор стартует вызовом start(). Там
  реализована машина состояний, которая сначала подключается к калибратору,
  затем стирает внешнюю память калибратора, затем передает
  подготовленную прошивку.
*/
#ifndef CSVPUDEVICE_H
#define CSVPUDEVICE_H

#include "CsSerialPort.h"
#include "SvLib/SvSingleton.h"

#include <QObject>
#include <QTimer>
#include <QElapsedTimer>

using CsSerialChannelPtr = QScopedPointer<CsSerialChannel>;

class CsVpuDevice : public QObject
  {
    Q_OBJECT

    CsSerialChannelPtr mSerialChannel;          //!< Рабочий порт для доступа к контроллеру
    QString            mController;             //!< Наименование контроллера
    int                mConnectCount;           //!< Механизм подавления дергания порта в linux
                                                //!  После подключения мы отправляем запрос info и ждем несколько
                                                //!  секунд, перед переходом к обычной работе. Если за это время
                                                //!  подключение не сбросилось, то все ок, иначе все по новой.

    int                mPortIndex;              //!< Счетчик перебора доступных портов для подключения к контроллеру
    int                mFlashAddress;           //!< Текущий адрес флэш для записи, -1 - когда записи нету
    int                mFlashCount;             //!< Количество байт для записи во флэш
    quint8             mFlashData[1050000];     //!< Буфер данных флэш

    int                mReceived;               //!< Счетчик для определения отсутствия ответа

    CsMessageOut       mOut;

    explicit CsVpuDevice(QObject *parent = nullptr);
  public:
    SV_SINGLETON(CsVpuDevice)

    bool isLink() const { return !mController.isEmpty(); }

    bool loadHex( const QString &configFile );

    void start();

  signals:

  public slots:

  private slots:
      //!
      //! \brief periodic Периодическая функция для связи с контроллером
      //!
      void periodic();

      //!
      //! \brief msgPeriodic Периодическая функция для повтора передачи при ошибке обмена
      //!
      void msgPeriodic();

      //!
      //! \brief bytesRead Слот вызывается при наличии байтов для чтения
      //!
      void bytesRead();

  private:
      //!
      //! \brief portClose Закрыть последовательный порт
      //!
      void portClose();

      //!
      //! \brief queryInfo Запросить информацию по контроллеру
      //!
      void queryInfo();

      //!
      //! \brief flashData Создать сообщение с прошивкой флэш и отправить
      //!
      void flashData();

      //!
      //! \brief parseUpgrade     Парсить hex файл и готовить его для передачи в контроллер
      //! \param upgradeFile      Имя файла
      //! \param upgradeByteCount Количество байт, размещенных в буфере прошивки
      //! \return                 true - когда файл распарсен успешно
      //!
      bool parseUpgrade( const QString &upgradeFile, int &upgradeByteCount );

      void appendFlashData( quint32 v );

      void appendFlashByte( quint8 v );

  };

#endif // CSVPUDEVICE_H
