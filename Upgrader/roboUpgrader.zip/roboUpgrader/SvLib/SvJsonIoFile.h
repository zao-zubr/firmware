#ifndef SVJSONIOFILE_H
#define SVJSONIOFILE_H

#include "SvJsonIO.h"

#include <QFileInfo>
#include <QFile>

inline bool svJsonFileWrite( SvJsonWriter &sd, const QString fileName, const QString fileExtension, const QString fileType, int baseVersion, bool bin = false )
  {
  sd.jsonString( "AType", fileType );
  sd.jsonInt( "AVersion", baseVersion );

  QString fname;
  if( !fileName.endsWith( fileExtension ) )
    fname = fileName + fileExtension;
  else
    fname = fileName;

  QFile file(fname);
  if( file.open(QIODevice::WriteOnly) ) {
    if( bin )
      file.write( svJsonObjectToCbor( sd.object() ) );
    else
      file.write( svJsonObjectToByteArray( sd.object() ) );
    return true;
    }
  return false;
  }


inline bool svJsonFileRead( QJsonObject &obj, const QString fileName, const QString needFileType, int &baseVersion, bool bin = false )
  {
  QFile file(fileName);
  if( file.open(QIODevice::ReadOnly) ) {
    if( bin )
      obj = svJsonObjectFromCbor( file.readAll() );
    else
      obj = svJsonObjectFromByteArray( file.readAll() );

    SvJsonReader sd( obj );
    QString fileType;
    sd.jsonString( "AType", fileType );
    sd.jsonInt( "AVersion", baseVersion );

    return fileType == needFileType;
    }
  return false;
  }


#endif // SVJSONIOFILE_H
