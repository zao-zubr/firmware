/*
   Проект "Серводвигатель для роботов Zubr"
   Автор
     Сибилев А.С.
   Описание
     StMessageZubr - реализация протокола сообщений с сервомашиной собственной разработки Zubr

     Учитывая требования высокой скорости передачи, прежние алгоритмы приема и отправки сообщений
     включая их детектирование - не годятся. Используемая система работы по прерываниям не успевает
     обработать поступающие байты. Было принято решение задействовать систему dma.

     Для системы приема по dma характерна необходимость заранее знать длительность данных, что
     в условиях протокола переменной длины не возможно. Поэтому прием ведется в кольцевой буфер
     постоянно, а программа в своем темпе пытается анализировать принятые данные. В этой связи
     актуальным делается вопрос обозначения начала фрейма (посылки, сообщения). Прежняя система
     детектирования пауз между посылками представляется нереальной для реализации. Было принято
     решение старший бит в байтах отдать под сигнал команда-данные. Это решает вопрос с определением
     начала посылки, но несколько усложняет упаковку данных.

     Таким образом сообщение теперь представляет собой посылку битов, упакованных в байты таким
     образом, что первый байт сообщения имеет в старшем бите 0, а остальные байты сообщения
     имеют в старшем бите 1.

     На передачу
       - заголовок: код команды и идентификатор двигателя
       - данные: один или несколько байтов данных
     На прием
       - заголовок:  код команды и идентификатор двигателя
       - данные: один или несколько байтов данных

       Заголовок
       7 6 5 4  3 2 1 0
       0 -cmd-  --id---

       Команды cmd:
       0 - команда управления, отправка данных воздействия 16бит и получение данных состояния 2*16бит
       1 - получить данные состояния 3*16бит
       2 - резерв
       3
       4
       5 - записать параметр, индекс параметра 16бит, значение параметра 32бит
       6 - прочитать параметр, индекс параметра 16бит
       7 - прошивка, адрес прошивки 32бит, данные прошивки 32бит

       Идентификатор мотора id. Поддерживается 15 двигателей. Двигатель с id = 0 значение по сбросу,
       двигатель с id = 15 универсальный идентификатор для прошивки

       [0] Команда управления:
         Заголовок, Воздействие 2 байт, КС
       ответ
         Текущий угол 2 байт, текущий момент 2 байт, КС

       [1] Получить данные состояния
         Заголовок, КС
       ответ
         3*16 значений состояния, КС

       [2] Расширенная команда управления:
         Заголовок, 16 бит целевое положение, 12 бит скорость, КС
       ответ
         16 бит положение, 12 бит ШИМ, 12 бит скорость, 12 бит ток, 4 бит флаги, КС

       [3] Компактная команда управления:
         Заголовок, 16 бит целевое положение, 12 бит скорость, КС (6 байт)
       ответ
         16 бит положение, 12 бит ШИМ, 12 бит скорость, 2 бит флаги, КС (7 байт)

       [5] Записать параметр:
         Заголовок, Индекс параметра (2байт), Параметр (4байта), КС
       ответ
         Параметр (4байта), КС

       [6] Прочитать параметр:
         Заголовок, Индекс параметра (2байт), КС
       ответ
         Параметр (4байта), КС

       [7] Прошивка
         В режиме прошивки заголовок равен 0x7f
         Заголовок 4 байта адрес, 4 байта слово, КС
       ответ
         1 байт - идентификатор устройства, в старших битах которого код ошибки или 0, если ошибок нету
                  0000 -id- в поле id возвращается идентификатор устройства
                   -+-
                    +------ код состояния (0-7)
                            0 - нету ошибок
         4 байта   значение или адрес





   Учитывая, что один из вариантов обмена с хостом - это uart, то целесообразно
   унифицировать обмен между хостом и контроллером.
   Поскольку контроллер один и различие по идентификатору не требуется, решено
   отдать под код команды весь заголовок.

       Заголовок
       7 6 5 4  3 2 1 0
       0 ----cmd-------

   Конкретные коды команд и состав посылок представлены в файле roboComBook.h

 История
   12.01.2023  v1 начал вести версии
   */
#ifndef CSMESSAGE_H
#define CSMESSAGE_H

#include <stdint.h>

//Версия сообщения
#define CS_MESSAGE_VERSION     1

//Команды
#define CS_CMD_MSG_CONTROL     0    //!< Управление 16бит, возвращает состояние 2*16бит
#define CS_CMD_MSG_INFO        1    //!< Получить информацию, возвращает набор параметров 3*16бит
#define CS_CMD_MSG_CONTROL_EX  2    //!< Управление 16бит, резерв 16бит, возвращает 3*16бит, 8бит, 7бит crc
#define CS_CMD_MSG_WRITE       5    //!< Запись параметра (индекс 16бит, значение 32бит, возвращает записанное значение 32бит)
#define CS_CMD_MSG_READ        6    //!< Чтение параметра (индекс 16бит, возвращает значение 32бит)
#define CS_CMD_MSG_FLASH       7    //!< Прошивка (адрес 32бит, значение 32бит)

//Длина сообщения прошивки
#define CS_CMD_FLASH_LENGTH   12

//                             CTRL INFO CTRL_EX        WR RD FLASH
//                              0    1    2       3  4    5  6  7
#define CS_CMD_LENGHTS        { 5,   2,   6,      0, 0,   9, 5, CS_CMD_FLASH_LENGTH } //!< Длины команд


//Сигнатуры устройств
#define CS_SIGNATURE_CONFIG   1939 //!< Сигнатура конфигурации
#define CS_SIGNATURE_MFLASH   1940 //!< Загрузчик для серводвигателей в металлическом и пластиковом корпусах
#define CS_SIGNATURE_MOTOR    1946 //!< Стандартный двигатель в металлическом корпусе
#define CS_SIGNATURE_LMOTOR   1948 //!< Двигатель в пластиковом корпусе
#define CS_SIGNATURE_MOTOR21  1949 //!< Серводвигатель в металлическом корпусе с 21-битным энкодером
#define CS_SIGNATURE_BLDC     1950 //!< Серводвигатель BLDC
#define CS_SIGNATURE_LMOTOR21 1951 //!< Серводвигатель в пластиковом корпусе с 21-битным энкодером
#define CS_SIGNATURE_TENSO    1812
#define CS_SIGNATURE_FORCE    1905 //!< Датчик усилия
#define CS_SIGNATURE_HOLL     1904 //!< Измеритель на основе датчиков Холла

//Коды ошибок прошивки
#define CS_UE_NONE             0 //!< Нету ошибок
#define CS_UE_SWITCH           1 //!< Ошибка переключения в режим прошивки
#define CS_UE_ERASE            2 //!< Ошибка стирания памяти
#define CS_UE_FLASH          100 //!< Адрес ошибки прошивки


//Кодовая книга
//Для всех устройств
#define CS_CB_SIGNATURE        0 //!< Сигнатура устройства
#define CS_CB_VERSION          1 //!< Версия программы
#define CS_CB_DEVICE_ID        2 //!< Идентификатор устройства
#define CS_CB_PROTOCOL_ID      3 //!< Идентификатор протокола обмена с устройством
#define CS_CB_DEVICE_MODE      4 //!< Режим работы устройства

#define CS_CB_UART_ZUBR_BASE   5
#define CS_CB_BAUDRATE         5 //!< Скорость обмена


//Загрузчик Flash серводвигателей в металлическом и пластиковом корпусах
#define CS_CB_START_PROG      10 //!< Запустить рабочую программу
#define CS_CB_INIT_CONFIG     11 //!< Стереть записанную конфигурацию, она будет по умолчанию
#define CS_CB_RESET_MODE      12 //!< Установить режим по умолчанию
#define CS_CB_SET_PROTOCOL    13 //!< Установить заданный протокол обмена
#define CS_CB_ERASE_PROG      14 //!< Стереть записанную программу


//Наборы для различных устройств
//Специфические параметры модуля IMU
#define CS_CB_TIME_SEC_LOW    10 //!< Секунды штампа времени
#define CS_CB_X               11
#define CS_CB_Y               12
#define CS_CB_Z               13
#define CS_CB_W               14
#define CS_CB_ACC             15


//Специфические параметры измерителя на датчиках холла
#define CS_CB_HOLL_CH0            10
#define CS_CB_HOLL_CH1            11
#define CS_CB_HOLL_CH2            12


//Специфические параметры двигателя
#define CS_CB_ANGLE_BASE          10

#define CS_CB_ADC_BASE           200

#define CS_CB_TARGET_PWM         100 //Значение ШИМ
#define CS_CB_CONTROL_VALUE      500 //Значение целевого значения регулятора

#define CS_CB_RANGLE_PID_BASE     60 //Регулятор позиции RL
#define CS_CB_RANGLE_VELO_BASE   110 //Регулятор скорости

#define CS_CB_RLIGHT_VELO_BASE   220
#define CS_CB_RLIGHT_SPRING_BASE 240

#define CS_CB_RMOMENT_VELO_BASE  300
#define CS_CB_RMOMENT_FRIC_BASE  310

#define CS_CB_RCALIBR_VELO_BASE  350
#define CS_CB_RCALIBR_PID_BASE   370

#define CS_CB_RANGLE_T_BASE      600 //Регулятор позиции

#define CS_CB_RPID_PID_BASE      700
#define CS_CB_RPID_VELO_BASE     740

//Специфические параметры двигателя с измерителем тока и 21-битным энкодером
#define CS_CB_CURRENT_BASE       250 //Регулятор тока

//Специфические параметры измерителя усилия
#define CS_CB_FORCE_TOP           10
#define CS_CB_FORCE_BOT           11
#define CS_CB_FORCE_TOP_MIN       12
#define CS_CB_FORCE_TOP_MAX       13


//Диапазон воздействий не покрывает весь диапазон значений, отправляемый в команде
// "воздействие". Поэтому мы можем специальными числами передавать в данной команде
// особые режимы работы устройств
#define CS_UM_FREE                 32767 //!< Шим от двигателя отключен
#define CS_UM_HOLD                 32766 //!< Удерживаем текущую позицию
#define CS_UM_SOFT                 32765 //!< Удерживаем текущую позицию давая возможность его изменить (пластилин)
#define CS_UM_NONE                 32764 //!< Значение не задано
#define CS_UM_SET_ZERO             32763 //!< Зафиксировать нулевую позицию
#define CS_UM_ZERO_UNLOCK          32762 //!< Разблокировать фиксацию нулевой позиции
#define CS_UM_ZP_UNLOCK            32761 //!< Разблокировать функцию настройки нулевой позиции
#define CS_UM_ZP_LOCK              32760 //!< Заблокировать функцию настройки нулевой позиции
#define CS_UM_ZP_SET_FACTORY       32759 //!< Установить заводской нулевой угол и диапазон +-150градусов
#define CS_UM_ZP_SET_NULL          32758 //!< Установка нулевого угла относительно нулевого заводского
#define CS_UM_ZP_SET_BEGIN         32757 //!< Установить значение граничного начального угла относительно нулевого
#define CS_UM_ZP_SET_END           32756 //!< Установить значение граничного конечного угла относительно нулевого
#define CS_UM_ZP_RESET_NULL        32755 //!< Установить текущий угол в качестве нулевого
#define CS_UM_PWM_ON               32754 //!< Включить режим прямой подачи ШИМ
#define CS_UM_PWM_OFF              32753 //!< Отключить режим прямой подачи ШИМ



//Смещение угла для возможности регулировки в диапазоне
#define CS_ANGLE_OFFSET             1000

//Диапазон регулировки углов
#define CS_ANGLE_MIN                   0 //!< Минимальный угол регулирования 0 градусов
#define CS_ANGLE_MAX               14000 //!< Максимальный угол регулирования 307.6 градуса

//При подаче чисел в диапазоне 20000+-4000 система отправляет их прямиком на PWM
#define CS_PWM_CENTRAL             20000 //!< Нулевое значение ШИМ


//Обмен с milk-v duo
#define CS_DUO_RX_SIZE              256  //!< Размер блока данных приемной части
#define CS_DUO_TX_SIZE              256  //!< Размер блока данных передающей части
#define CS_DUO_SIZE                (CS_DUO_RX_SIZE + CS_DUO_TX_SIZE)

//Типы блоков
#define FDUOB_LAST                  0 //!< Заключительный блок в посылке, далее блоков нету
#define FDUOB_ANSWER                1 //!< признак корректного ответа
#define FDUOB_MODEL                 1 //!< u8 u8 u8 последовательно: номер модели, длина входного вектора, длина выходного вектора
#define FDUOB_VALUE_FLOAT           2 //!< f32 прямое значение
#define FDUOB_TIME                  3 //!< i32 счетчик фреймов, i8 период фреймов в мс
#define FDUOB_PHASE                 4 //!< i32 счетчик фреймов, из которого делаются 2 фазы, i8 период фреймов в мс
#define FDUOB_IMU_ACC               5 //!< 3*16 значений из IMU акселератор, для получения физических величин необходимо делить на 4096.0
#define FDUOB_IMU_GYRO              6 //!< 3*16 значений из IMU гироскоп, для получения физических величин необходимо делить на 2048.0
#define FDUOB_IMU_QUATER            7 //!< 4*16 значений из IMU кватернион, для получения физических величин необходимо делить на 16384.0
#define FDUOB_IMU_QUATER_GRAVI      8 //!< 4*16 значений из IMU кватернион, из этого необходимо получить вектор гравитации
#define FDUOB_ANGLE_8               9 //!< 8*16 значений угла, для преобразования в радианы необходимо умножить на 0.000383495
#define FDUOB_ANGLE_4              10 //!< 4*16 значений угла, для преобразования в радианы необходимо умножить на 0.000383495
#define FDUOB_ANGLE_2              11 //!< 2*16 значений угла, для преобразования в радианы необходимо умножить на 0.000383495
#define FDUOB_ANGLE_1              12 //!< 1*16 значений угла, для преобразования в радианы необходимо умножить на 0.000383495
#define FDUOB_VELO_8               13 //!< 8*12 значений скорости, для преобразования в радианы/сек нужно умножить на 0.003081659
#define FDUOB_VELO_4               14 //!< 4*12 значений скорости, для преобразования в радианы/сек нужно умножить на 0.003081659
#define FDUOB_VELO_2               15 //!< 2*12 значений скорости, для преобразования в радианы/сек нужно умножить на 0.003081659
#define FDUOB_VELO_1               16 //!< 1*12 значений скорости, для преобразования в радианы/сек нужно умножить на 0.003081659
#define FDUOB_SKEEP                23 //!< i8 пропустить заданное количество ячеек
#define FDUOB_ANGLE_R8             24 //!< чтение 8*16 значений угла, для преобразования из радиан нужно делить на 0.000383495
#define FDUOB_ANGLE_R4             25 //!< чтение 4*16 значений угла, для преобразования из радиан нужно делить на 0.000383495
#define FDUOB_ANGLE_R2             26 //!< чтение 2*16 значений угла, для преобразования из радиан нужно делить на 0.000383495
#define FDUOB_ANGLE_R1             27 //!< чтение 1*16 значений угла, для преобразования из радиан нужно делить на 0.000383495


inline int csMessageId( char ch ) { return ch & 0xf; }

inline int csMessageCmd( char ch ) { return (ch >> 4) & 0x7; }

class CsMessageOutBase
  {
    char  mBuffer[65];   //! Буфер для размещения закодированных данных
    int   mPtr;          //! Номер текущего байта
    int   mUsedBits;     //! Количество свободных битов в текущем байте
  public:
    CsMessageOutBase() : mPtr(0), mUsedBits(0) {}

    //!
    //! \brief addIntN Добавить N-битное значение
    //! \param val     Значение
    //! \param bits    Количество бит значения
    //!
    void addIntN( int val, int bits );

    //!
    //! \brief addInt8 Добавить 8-битное значение
    //! \param val 8-битное значение
    //!
    void addInt8( int val );

    //!
    //! \brief addInt7 Добавить 7-битное значение
    //! \param val     7-битное значение
    //!
    void addInt7( int val );

    //!
    //! \brief addInt14 Добавить 14-битное значение
    //! \param val      14-битное значение
    //!
    void addInt14( int val );

    //!
    //! \brief addInt12 Добавить 12-битное значение
    //! \param val      12-битное значение
    //!
    void addInt12( int val );

    //!
    //! \brief addIntL7 Шаблонная функция добавляет значение размером size бит (должно быть меньше семи)
    //! \param val      Значение размером size бит
    //!
    template <int size>
    void addIntL7( int val )
      {
      //Удаляем старшие биты
      val &= 0x7f >> (7-size);

      //Добавляем биты в текущий байт
      mBuffer[mPtr] |= (val << mUsedBits) | 0x80;

      //Количество битов добавленных выше
      int bits = 7 - mUsedBits;

      //Проверяем, поместилось ли значение целиком в текущий байт
      if( bits <= size ) {
        //Требуется выделение очередного байта
        //Либо значение не поместилось либо текущий байт забит под завязку
        mPtr++;
        mBuffer[mPtr] = (val >> bits) | 0x80;
        mUsedBits = size - bits;
        }
      else
        //Значение целиком поместилось в текущий байт
        mUsedBits += size;
      }


    //!
    //! \brief addInt16 Добавить 16-битное значение
    //! \param val 16-битное значение
    //!
    void addInt16( int val );

    //!
    //! \brief addInt32 Добавить 32-битное значение
    //! \param val 32-битное значение
    //!
    void addInt32( int val );

    //!
    //! \brief addFloat Добавить 32-битное с плавающей точкой
    //! \param val      32-битное с плавающей точкой
    //!
    void addFloat( float val );

    //!
    //! \brief addBlock Добавить блок байтов
    //! \param block    Блок байтов
    //! \param size     Размер блока
    //!
    void addBlock( const char *block, int size );

    //!
    //! \brief beginQuery Инициализация буфера командой cmd. После инициализации можно добавлять данные
    //! \param cmd        Формируемая команда
    //! \param id         Идентификатор устройства, которому адресована данная команда
    //!
    void beginQuery( char cmd, int id );

    //!
    //! \brief beginAnswer Инициализация буфера для ответа. После инициализации можно добавлять данные
    //!
    void beginAnswer();

    //!
    //! \brief hostBeginQuery Инициализация буфера командой cmd. После инициализации можно добавлять данные
    //! \param cmd            Формируемая команда
    //!
    void hostBeginQuery( char cmd );

    //!
    //! \brief hostBeginAnswer Инициализация буфера для ответа. После инициализации можно добавлять данные
    //!
    void hostBeginAnswer() { beginAnswer(); }

    //!
    //! \brief hostEnd Завершение формирования команды, дописывание контрольной суммы и символа \n
    //!
    void hostEnd();

    //!
    //! \brief end Завершение формирования команды и дописывание контрольной суммы
    //!
    void end();

    //!
    //! \brief lenght Возвращает текущую заполненную длину буфера
    //! \return       Длина заполненной части буфера
    //!
    int  length() const { return mPtr; }

    //!
    //! \brief buffer Возвращает буфер с сформированной строкой. Строка имеет завершающий символ \n и 0 на конце.
    //! \return Указатель на начало буфера
    //!
    const char *buffer() const { return mBuffer; }


    //==================================================================
    //  Комплексные операции
    //!
    //! \brief makeQueryControl Сформировать команду "Управление"
    //! \param id               Идентификатор устройства
    //! \param value            Значение управления
    //!
    void     makeQueryControl( int id, int value );

    //!
    //! \brief makeQueryControlEx Сформировать команду "Расширенное управление"
    //! \param id                 Идентификатор устройства
    //! \param target16           Целевое значение
    //! \param velo12             Скорость в целевом значении
    //!
    void     makeQueryControlEx( int id, int target16, int velo12 );



    //!
    //! \brief makeAnswerControl Сформировать ответ на команду "Управление"
    //! \param angle             Текущий угол сервы
    //! \param moment            Текущий момент
    //!
    void     makeAnswerControl( int angle, int moment );

    //!
    //! \brief makeAnswerControlEx Сформировать ответ на команду "Расширенное управление"
    //! \param angle16             Текущее положение угла
    //! \param pwm12               Текущий ШИМ
    //! \param velo12              Текущая скорость
    //! \param current12           Текущий ток
    //! \param flags4              Набор флагов-признаков
    //!
    void     makeAnswerControlEx( int angle16, int pwm12, int velo12, int current12, int flags4 );



    //!
    //! \brief makeQueryInfo Сформировать команду "Получить информацию"
    //! \param id            Идентификатор устройства
    //!
    void     makeQueryInfo( int id );

    //!
    //! \brief makeAnswerInfo  Сформировать ответ на команду "Получить информацию"
    //! \param val0            Значение 0
    //! \param val1            Значение 1
    //! \param val2            Значение 2
    //!
    void     makeAnswerInfo( int val0, int val1, int val2 );

    //!
    //! \brief makeQueryWrite Сформировать команду "Запись параметра"
    //! \param id             Идентификатор устройства
    //! \param index          Индекс параметра
    //! \param value          Значение параметра
    //!
    void     makeQueryWrite( int id, int index, int value );

    //!
    //! \brief makeAnswerWrite Сформировать ответ на команду "Запись параметра"
    //! \param value           Значение, записанное в параметр
    //!
    void     makeAnswerWrite( int value );

    //!
    //! \brief makeQueryRead Сформировать команду "Чтение параметра"
    //! \param id            Идентификатор устройства
    //! \param index         Индекс параметра
    //!
    void     makeQueryRead(int id, int index );

    //!
    //! \brief makeAnswerRead Сформировать ответ на команду "Чтение параметра"
    //! \param index          Индекс параметра
    //! \param value          Значение параметра
    //!
    void     makeAnswerRead( int value );

    //!
    //! \brief makeQueryFlash Сформировать команду "Прошивка"
    //! \param id             Идентификатор устройства
    //! \param adrOrCmd       Адрес прошивки или команда
    //! \param value          Значение прошивки
    //!
    void     makeQueryFlash( int id, int adrOrCmd, int value );




    //!
    //! \brief crc  Вычисление контрольной суммы для блока данных
    //! \param buf  Буфер с данными, на которых вычисляется контрольная сумма
    //! \param size Размер данных в байтах
    //! \return     Контрольная сумма
    //!
    static int  crc( const char *buf0, int size0, const char *buf1 = nullptr, int size1 = 0 );
  };









//!
//! \brief floatToUInt Упаковка числа с плавающей точкой в тридцатидвухразрядную ячейку
//! \param val         Число с плавающей точкой
//! \return            Упакованное число с плавающей точкой
//!
inline uint32_t floatToUInt( float val )
  {
  // We need to do this in order to access the bits from our float
  uint32_t *u = reinterpret_cast<uint32_t*>(&val);
  return *u;
  }

//!
//! \brief floatFromUInt Распаковка из тридцатидвухразрядной ячейки в число с плавающей точкой
//! \param val           Упакованное число с плавающей точкой
//! \return              Число с плавающей точкой
//!
inline float    floatFromUInt( uint32_t val )
  {
  float *f = reinterpret_cast<float*>(&val);
  return *f;
  }





template <int N>
class CsMessageOutPat
  {
    char  mBuffer[N];    //! Буфер для размещения закодированных данных
    int   mPtr;          //! Номер текущего байта
    int   mUsedBits;     //! Количество свободных битов в текущем байте
  public:
    CsMessageOutPat() : mPtr(0), mUsedBits(0) {}

    //!
    //! \brief addIntL7 Шаблонная функция добавляет значение размером size бит (должно быть меньше семи)
    //! \param val      Значение размером size бит
    //!
    template <int size>
    void addInt( int val )
      {
      //Удаляем старшие биты
      val &= 0xffffffff >> (32-size);

      //Количество битов добавленных выше
      int bits = 7 - mUsedBits;

      if constexpr (size <= 7) {

        //Добавляем биты в текущий байт
        mBuffer[mPtr] |= (val << mUsedBits) | 0x80;

        //Проверяем, поместилось ли значение целиком в текущий байт
        if( bits <= size ) {
          //Требуется выделение очередного байта
          //Либо значение не поместилось либо текущий байт забит под завязку
          mPtr++;
          mBuffer[mPtr] = (val >> bits) | 0x80;
          mUsedBits = size - bits;
          }
        else
          //Значение целиком поместилось в текущий байт
          mUsedBits += size;
        }
      else {
        //Добавляем биты в текущий байт
        mBuffer[mPtr++] |= (val << mUsedBits) | 0x80;

        val >>= bits;
        if constexpr (size == 32) {
          //Для 32-разрядного числа обеспечим старший бит нулевым
          // чтобы при сдвиге вправо не дублировался знаковый разряд
          val &= 0xffffffff >> (32-(size - bits));
          }
        bits = size - bits;
        while( bits >= 7 ) {
          mBuffer[mPtr++] = val | 0x80;
          val >>= 7;
          bits -= 7;
          }
        mUsedBits = bits;
        mBuffer[mPtr] = val | 0x80;
        }
      }


    //!
    //! \brief addInt8 Добавить 8-битное значение
    //! \param val 8-битное значение
    //!
    void addInt8( int val ) { addInt<8>( val ); }


    //!
    //! \brief addInt12 Добавить 12-битное значение
    //! \param val      12-битное значение
    //!
    void addInt12( int val ) { addInt<12>( val ); }

    //!
    //! \brief addInt14 Добавить 14-битное значение
    //! \param val      14-битное значение
    //!
    void addInt14( int val ) { addInt<14>( val ); }

    //!
    //! \brief addInt16 Добавить 16-битное значение
    //! \param val 16-битное значение
    //!
    void addInt16( int val ) { addInt<16>( val ); }

    //!
    //! \brief addInt32 Добавить 32-битное значение
    //! \param val 32-битное значение
    //!
    void addInt32( int val ) { addInt<32>( val ); }

    //!
    //! \brief addFloat Добавить 32-битное с плавающей точкой
    //! \param val      32-битное с плавающей точкой
    //!
    void addFloat( float val ) { addInt32( floatToUInt(val) ); }



    //!
    //! \brief addBlock Добавить блок байтов
    //! \param block    Блок байтов
    //! \param size     Размер блока
    //!
    void addBlock( const char *block, int size )
      {
      while( size-- )
        addInt8( *block++ );
      }


    //!
    //! \brief addFill Добавляет в конец буфера size байтов ch
    //! \param size    Количество добавляемых байтов
    //! \param ch      Добавляемый байт
    //!
    void addFill( int size, char ch = 0x80 )
      {
      if( size >= 0 ) {

        if( mUsedBits ) {
          //Пропускаем частично заполненный байт
          mPtr++;
          mUsedBits = 0;
          }

        //Добавляем заданное количество байтов
        while( size-- )
          mBuffer[mPtr++] = ch;

        //Текущий байт обнуляем
        mBuffer[mPtr] = 0;
        }
      }


    //!
    //! \brief addFillTo Добавляет в конец буфера необходимое количество байтов, чтобы добить до общее количество до limit
    //! \param limit     Требуемый размер буфера
    //! \param ch        Добавляемый байт
    //!
    void addFillTo( int limit, char ch = 0x80 )
      {
      addFill( limit - mPtr + (mUsedBits ? -1 : 0), ch );
      }



    //!
    //! \brief beginQuery Инициализация буфера командой cmd. После инициализации можно добавлять данные
    //! \param cmd        Формируемая команда
    //! \param id         Идентификатор устройства, которому адресована данная команда
    //!
    void beginQuery( char cmd, int id )
      {
      mUsedBits = 0;
      mPtr = 1;
      mBuffer[0] = ((cmd << 4) & 0x70) | (id & 0xf);
      mBuffer[1] = 0;
      }

    //!
    //! \brief beginAnswer Инициализация буфера для ответа. После инициализации можно добавлять данные
    //!
    void beginAnswer()
      {
      mUsedBits = 0;
      mPtr = 0;
      mBuffer[0] = 0;
      }

    //!
    //! \brief hostBeginQuery Инициализация буфера командой cmd. После инициализации можно добавлять данные
    //! \param cmd            Формируемая команда
    //!
    void hostBeginQuery( char cmd )
      {
      mUsedBits = 0;
      mPtr = 1;
      mBuffer[0] = ((cmd) & 0x7f);
      mBuffer[1] = 0;
      }

    //!
    //! \brief hostBeginAnswer Инициализация буфера для ответа. После инициализации можно добавлять данные
    //!
    void hostBeginAnswer() { beginAnswer(); }

    //!
    //! \brief hostEnd Завершение формирования команды, дописывание контрольной суммы и символа \n
    //!
    void hostEnd()
      {
      //Завершаем и КС
      end();
      mBuffer[mPtr++] = '\n';
      mBuffer[mPtr] = 0;
      }

    //!
    //! \brief end Завершение формирования команды и дописывание контрольной суммы
    //!
    void end()
      {
      if( mUsedBits ) mPtr++;
      mBuffer[mPtr] = CsMessageOutBase::crc( mBuffer, mPtr ) | 0x80;
      mBuffer[++mPtr] = 0;
      }

    //!
    //! \brief lenght Возвращает текущую заполненную длину буфера
    //! \return       Длина заполненной части буфера
    //!
    int  length() const { return mPtr; }

    //!
    //! \brief bufferConst Возвращает буфер с сформированной строкой. Строка имеет завершающий символ \n и 0 на конце.
    //! \return Указатель на начало буфера
    //!
    const char *bufferConst() const { return mBuffer; }

    //!
    //! \brief ubufferConst Возвращает буфер с сформированной строкой как массив байтов
    //! \return             Массив беззнаковых байтов
    //!
    const unsigned char *ubufferConst() const { return (const unsigned char*)mBuffer; }

    //!
    //! \brief buffer Возвращает буфер с сформированной строкой. Разрешаем заменить содержимое буфера при передаче SPI
    //! \return       Указатель на начало буфера
    //!
    char *buffer() { return mBuffer; }

    //!
    //! \brief ubuffer Возвращает буфер с сформированной строкой как массив байтов. Разрешаем заменить содержимое буфера при передаче SPI
    //! \return        Массив беззнаковых байтов
    //!
    unsigned char *ubuffer() { return (unsigned char*)mBuffer; }
  };



using CsMessageOut = CsMessageOutBase;



template <int len>
struct CsMessageBuf
  {
    const int mSize = len;  //!< Константный размер буфера
    char      mBuffer[len]; //!< Буфер, содержащий принятый блок данных
    int       mLength;      //!< Количество данных в буфере

    CsMessageBuf() : mLength(0) {}
  };


using CsMessageBuf256 = CsMessageBuf<256>;







template <int N>
class CsMessageInPat
  {
    char  mBuffer[N];    //! Буфер для размещения закодированных данных
    int   mPtr;          //! Номер текущего байта
    int   mUsedBits;     //! Количество свободных битов в текущем байте
  public:
    CsMessageInPat() : mPtr(0), mUsedBits(0) {}


    //!
    //! \brief maxSize Возвращает максимальный размер буфера
    //! \return        Размер буфера для данных
    //!
    int  maxSize() const { return N; }

    //!
    //! \brief pos Возвращает текущую позицию чтения
    //! \return    Текущая позиция чтения
    //!
    int  pos() const { return mPtr; }

    //!
    //! \brief buffer Возвращает указатель на начало буфера
    //! \return       Указатель на начало буфера
    //!
    char *buffer() { mPtr = 1; mUsedBits = 0; return mBuffer; }

    //!
    //! \brief ubuffer Возвращает указатель на начало буфера как буфера беззнаковых байтов
    //! \return        Буфер беззнаковых байтов
    //!
    unsigned char *ubuffer() { return (unsigned char*)buffer(); }

    //!
    //! \brief cmd Возвращает код команды
    //! \return
    //!
    char  cmd() const { return mBuffer[0]; }

    void  reset( int startPos ) { mPtr = startPos; mUsedBits = 0; }


    //!
    //! \brief addIntL7 Шаблонная функция добавляет значение размером size бит (должно быть меньше семи)
    //! \param val      Значение размером size бит
    //!
    template <int size,bool isSigned>
    int getInt()
      {

      //Количество считанных битов
      int bits = 7 - mUsedBits;
      int val;

      if constexpr (size <= 7) {
        val = (mBuffer[mPtr] & 0x7f) >> mUsedBits;

        if( bits >= size ) {
          //Все биты считаны
          mUsedBits += size;
          if( mUsedBits == 7 ) {
            mPtr++;
            mUsedBits = 0;
            }
          }
        else {
          //Нужно прочитать из второго байта
          mPtr++;
          val |= (mBuffer[mPtr] & 0x7f) << bits;
          mUsedBits = size - bits;
          }
        }
      else {
        //Получаем первую порцию данных
        val = (mBuffer[mPtr++] & 0x7f) >> mUsedBits;

        bits = size - bits;
        while( bits >= 7 ) {
          val |= (mBuffer[mPtr++] & 0x7f) << (size - bits);
          bits -= 7;
          }
        mUsedBits = bits;
        if( bits )
          val |= (mBuffer[mPtr] & 0x7f) << (size - bits);
        }
      if constexpr (isSigned) {
        val <<= 32 - size;
        return val >> (32 - size);
        }
      else {
        return val & (0xffffffffu >> (32 - size));
        }
      }


    //!
    //! \brief getInt8 Извлекает 8-битное число
    //! \return        8-битное число со знаком
    //!
    int      getInt8() { return getInt<8,true>(); }
    unsigned getUInt8() { return getInt<8,false>(); }

    //!
    //! \brief getInt12 Извлекает 12-битное число
    //! \return         12-битное число со знаком
    //!
    int      getInt12() { return getInt<12,true>(); }
    unsigned getUInt12() { return getInt<12,false>(); }

    //!
    //! \brief getInt14 Извлекает 14-битное число
    //! \return         14-битное число со знаком
    //!
    int      getInt14() { return getInt<14,true>(); }
    unsigned getUInt14() { return getInt<14,false>(); }


    //!
    //! \brief getInt16 Извлекает 16-битное число
    //! \return         16-битное число со знаком
    //!
    int      getInt16() { return getInt<16,true>(); }
    unsigned getUInt16() { return getInt<16,false>(); }


    //!
    //! \brief getInt32 Извлекает 32-битное число
    //! \return         32-битное число со знаком
    //!
    int      getInt32() { return getInt<32,true>(); }
    unsigned getUInt32() { return getInt<32,false>(); }

    //!
    //! \brief getBlock Извлекает набор байтов
    //! \param dest Буфер-приемник байтов
    //! \param size Количество извлекаемых байтов
    //!
    void  getBlock( char *dest, int size )
      {
      while( size-- )
        *dest++ = getInt8();
      }

    //!
    //! \brief checkCrc Проверить совпадение контрольной суммы
    //! \param length   Длина сообщения
    //! \param offset   Смещение начала сообщения, если оно не с начала буфера
    //! \return         true когда контрольная сумма совпала
    //!
    bool  checkCrc( int length, int offset = 0 ) const
      {
      //Сократить длину до величины тела сообщения (исключаем кс)
      length--;

      //Вычисляем фактическую КС
      int crc0 = (CsMessageOutBase::crc( mBuffer + offset, length ) | 0x80);
      //Читаем КС из сообщения
      int crc1 = mBuffer[length + offset] & 0xff;
      return crc0 == crc1;
      }

  };



//!
//! \brief The CsMessageIn class служит для преобразования сообщения в бинарные данные.
//! Для кодирования служит класс CsMessageOut. Кодирование и декодирование полностью согласованы,
//! поэтому нечувствительны к различиям используемых платформ.
//! Данный класс поддерживает циклический буфер.
//!
class CsMessageIn
  {
    const char *mBuffer;   //!< Указатель на циклический буфер
    int         mStart;    //!< Индекс начала данных в циклическом буфере
    int         mBufSize;  //!< Размер циклического буфера
    int         mPtr;      //!< Номер текущего байта декодируемого сообщения
    int         mUsedBits; //!< Количество использованных битов в текущем байте

    char  at( int index ) const { index += mStart; return mBuffer[ index < mBufSize ? index : index - mBufSize ]; }
  public:
    //!
    //! \brief SvTextStreamIn Конструктор декодера
    //! \param buf Буфер, содержащий исходную строку
    //!
    CsMessageIn( const char *buf, short start, short size = 0x7fff, int ptr = 0 );

    template <class CsMessageBufTmpl>
    CsMessageIn( CsMessageBufTmpl &buf, int ptr = 0 ) : mBuffer(buf.mBuffer), mStart(0), mBufSize(buf.mSize), mPtr(ptr), mUsedBits(0) { }

    //!
    //! \brief id Возвращает идентификатор устройства, которому адресовано сообщение
    //! \return   Идентификатор устройства
    //!
    int   id() const { return csMessageId( at(0) ); }

    //!
    //! \brief cmd Возвращает команду сообщения
    //! \return    Команда сообщения
    //!
    int   cmd() const { return csMessageCmd( at(0) ); }

    //!
    //! \brief hostCmd Возвращает команду сообщения от хоста
    //! \return        Команда сообщения
    //!
    int   hostCmd() const { return at(0); }

    //!
    //! \brief reset Установить новое начало данных и сбросить номер текущего байта и счетчик битов
    //! \param start Индекс начала новых данных
    //! \param ptr   Индекс, с которого начинаем декодирование
    //!
    void  reset( int start , int ptr );

    //!
    //! \brief getUInt8 Извлекает 8-битное число предполагая, что оно беззнаковое
    //! \return         8-битное число
    //!
    int   getUInt8();

    //!
    //! \brief getInt8 Извлекает 8-битное число
    //! \return        8-битное число со знаком
    //!
    int   getInt8();

    //!
    //! \brief getUInt7 Извлекает 7-битное число
    //! \return         7-битное число без знака
    //!
    int   getUInt7();

    template <int size>
    int   getUInt7L()
      {
      //Получаем первую порцию данных
      int val = (at(mPtr) & 0x7f) >> mUsedBits;
      //Количество считанных битов
      int bits = 7 - mUsedBits;
      if( bits <= size ) {
        //Оставшиеся биты
        mPtr++;
        val |= ((at(mPtr) & 0x7f) << bits) & (0x7f >> (7-size) );
        mUsedBits = size - bits;
        }
      else
        //Значение целиком из текущего байта
        mUsedBits += size;
      return val;
      }

    //!
    //! \brief getInt14 Извлекает 14-битное число
    //! \return         14-битное число со знаком
    //!
    int   getInt14();

    //!
    //! \brief getInt12 Извлекает 12-битное число
    //! \return         12-битное число со знаком
    //!
    int   getInt12();

    //!
    //! \brief getUInt16 Извлекает 16-битное число предполагая, что оно беззнаковое
    //! \return          16-битное число
    //!
    int   getUInt16();

    //!
    //! \brief getInt16 Извлекает 16-битное число со знаком
    //! \return         16-битное число со знаком
    //!
    int   getInt16();

    //!
    //! \brief getInt32 Извлекает 32-битное число
    //! \return 32-битное число
    //!
    int   getInt32();

    //!
    //! \brief getBlock Извлекает набор байтов
    //! \param dest Буфер-приемник байтов
    //! \param size Количество извлекаемых байтов
    //!
    void  getBlock( char *dest, int size );

    //!
    //! \brief checkCrc Проверить совпадение контрольной суммы
    //! \param length   Длина сообщения
    //! \return         true когда контрольная сумма совпала
    //!
    bool  checkCrc( int length ) const;


    //==================================================================
    //  Комплексные операции
    //!
    //! \brief scanQueryControl Сканировать команду "Управление"
    //! \param value            Значение управления
    //!
    void scanQueryControl( int *value );

    //!
    //! \brief scanQueryControlEx Сканировать команду "Расширенное управление"
    //! \param target16           Целевое значение
    //! \param velo12             Скорость в целевом значении
    //!
    void scanQueryControlEx( int *target16, int *velo12 );



    //!
    //! \brief scanAnswerControl Сканировать ответ на команду "Управление"
    //! \param angle             Текущий угол сервы
    //! \param pwm               Текущий PWM
    //!
    void scanAnswerControl( int *angle, int *pwm );

    //!
    //! \brief scanAnswerControlEx Сканировать ответ на команду "Расширенное управление"
    //! \param angle16             Текущее положение угла
    //! \param pwm12               Текущий ШИМ
    //! \param velo12              Текущая скорость
    //! \param current12           Текущий ток
    //! \param flags4              Набор флагов-признаков
    //!
    void scanAnswerControlEx( int *angle16, int *pwm12, int *velo12, int *current12, int *flags4 );



    //!
    //! \brief scanAnswerInfo  Сканировать ответ на команду "Получить информацию"
    //! \param val0            Значение 0
    //! \param val1            Значение 1
    //! \param val2            Значение 2
    //!
    void scanAnswerInfo( int *val0, int *val1, int *val2 );

  };







#endif // CSMESSAGE_H
