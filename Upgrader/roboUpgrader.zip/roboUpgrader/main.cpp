/*
Project "Загрузчик прошивок в кабельный тестер"
Copyright (c) 2026 Alexander Sibilev

Author
  Alexander Sibilev S.

Web
  www.SalixEDA.org

Description
  Точка входа в программу

  Эта программа загружает во внешнюю флэш кабельного тестера (калибратора)
  прошивки движков для обеспечения возможности прошивки при помощи
  кабельного тестера.

  Идея в следующем: в файле config.hex находится конфигурация прошивок. По сути
  перечень файлов прошивки с наименованием прошивки. Это наименование выводится
  в меню калибратора при выборе прошивки.

  Это типовой файл конфигурации, он в формате JSON. Состоит из массива строк.
  Каждая пара строк определяет прошивку. Первая строка - полный путь к файлу прошивки.
  Вторая строка - наименование для отображения в меню.
{
    "hex files": [
        "/home/asibilev/work/robo/soft/roboUpgrader/hex/roboServoLBoardV1.hex",
        "Plastic enc14 v69",

        "/home/asibilev/work/robo/soft/roboUpgrader/hex/v71-roboServoLBoardV2.hex",
        "Plastic enc21 v71"
    ]
}

  Всю "грязную" работу делает CsVpuDevice. Он выпилен из IronArt, поэтому может иметь
  не относящиеся к делу артефакты.

*/

#include "CsVpuDevice.h"

#include <QCoreApplication>
#include <QFile>

int main(int argc, char *argv[])
  {
  QCoreApplication a(argc, argv);


  //Читаем файл конфигурации и подготавливаем массив данных
  CsVpuDevice::instance()->loadHex("/home/asibilev/work/robo/soft/roboUpgrader/hex/config.hex");

  //Обнаруживаем подключение к тестеру
  CsVpuDevice::instance()->start();

  return a.exec();
  }
